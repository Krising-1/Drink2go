/* в этот файл добавляет скрипты*/
import { burgerSwitching } from './burger.js';
import {addButtonsSwiper, paginationMove} from './hero-swiper.js';
import './price-slider.js';

burgerSwitching();
addButtonsSwiper();
paginationMove();

